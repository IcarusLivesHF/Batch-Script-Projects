sound effects are free assets found from various web pages on the internet.

I did not create, nor do I have any involvement in the creation of the .wav files within this project.

All credits of these .wavs file assets belong to the original creators.


https://kenney.nl/assets/interface-sounds
https://freesound.org/